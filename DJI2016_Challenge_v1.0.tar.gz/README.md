   *data*  2016-07-02
1	this project was changed for the odometry of M100, but not for the visual odometry (fovis);

2	the hardware of m100 was updated to v 1.3.10. Guidance-SDK-ROS haven't been upgrated.

3	when using the odometry of m100, the GPS signal must be provided aready, or there will be no odometry.
