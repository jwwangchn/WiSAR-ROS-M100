#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export CPATH="/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel/include:/home/kelfor/Documents/flir-vue-pro/devel/include:$CPATH"
export LD_LIBRARY_PATH="/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel/lib:/home/kelfor/Documents/flir-vue-pro/devel/lib:/opt/ros/indigo/lib:../clion-2016.3.3/bin:/usr/local/cuda-6.5/lib64"
export PKG_CONFIG_PATH="/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel/lib/pkgconfig:/home/kelfor/Documents/flir-vue-pro/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export PYTHONPATH="/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel/lib/python2.7/dist-packages:/home/kelfor/Documents/flir-vue-pro/devel/lib/python2.7/dist-packages:$PYTHONPATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam:$ROS_PACKAGE_PATH"