# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel/include".split(';') if "/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel/include" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "flir_vue_read_cam"
PROJECT_SPACE_DIR = "/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
