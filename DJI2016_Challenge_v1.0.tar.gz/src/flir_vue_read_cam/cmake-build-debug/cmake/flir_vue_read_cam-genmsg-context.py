# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/msg/proposal_roi_msg.msg"
services_str = ""
pkg_name = "flir_vue_read_cam"
dependencies_str = "std_msgs"
langs = "gencpp;genlisp;genpy"
dep_include_paths_str = "flir_vue_read_cam;/home/kelfor/Documents/flir-vue-pro/src/flir_vue_read_cam/msg;std_msgs;/opt/ros/indigo/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/indigo/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
