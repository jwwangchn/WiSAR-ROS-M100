1. roslaunch m100_2dnav m100_configuration.launch

2. roslaunch m100_2dnav move_base.launch

3. rosrun m100_base_controller base_controller

4. rosrun m100_navigation_goals navigation_goals
